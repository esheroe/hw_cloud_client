# -*- coding: utf-8 -*-
"""
Created on Mon Aug 26 13:48:38 2019

帮助AI做各种行为的帮助库
@author: GP63
"""

from ballclient.service.SharedDataBase import point #共享数据库




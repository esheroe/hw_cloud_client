#global variable here
# 调用方式为constants.variable
team_id = 3206
ai_id = 1111
team_name = "lx852357" # decided by yourself.

# -*- coding: utf-8 -*-
"""
Created on Mon Aug 26 13:48:38 2019

帮助list做矩阵运算的

@author: GP63
"""

import numpy as np

def mul(l1,l2):
    m1 = np.array(l1)
    m2 = np.array(l2)
    
    result = np.matmul(m1,m2)
    return result.tolist()

    

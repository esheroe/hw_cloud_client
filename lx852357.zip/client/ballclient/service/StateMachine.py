# -*- coding: utf-8 -*-
"""
Created on Fri Aug 23 14:04:34 2019

@author: GP63
"""

class StateMachine:
    def __init__(self): 
        self.handlers = {}        # 状态转移函数字典
        self.startState = None    # 初始状态
        self.endStates = []       # 最终状态集合
        self.handler = 0          # 状态转移函数
        self.nowState   = None
        '''
        
        '''
        self.transation = {}
    
    # 参数name为状态名,handler为状态转移函数,end_state表明是否为最终状态
    def add_state(self, name, handler, end_state=0):
        name = name.upper() # 转换为大写
        self.handlers[name] = handler
        if end_state:
            self.endStates.append(name)

    def set_start(self, name):
        self.startState = name.upper()
        self.nowState = name.upper()

    def run(self, newTrans):
        if self.nowState == self.startState:
            try:
                self.handler = self.handlers[self.startState]
            except:
                raise InitializationError("must call .set_start() before .run()")
            if not self.endStates:
                raise  InitializationError("at least one state must be an end_state")
        
        # 从Start状态开始进行处理
        '''
        while True: 
            (newState, cargo) = handler(cargo)     # 经过状态转移函数变换到新状态
            if newState.upper() in self.endStates: # 如果跳到终止状态,则打印状态并结束循环
                print("reached ", newState)
                break 
            else:                        # 否则将转移函数切换为新状态下的转移函数 
                handler = self.handlers[newState.upper()] 
        '''
 
        #newTrans = newTrans     # 经过状态转移函数变换到新状态
        newState = self.handler(newTrans)
        self.nowState = newState
        print("nowState:",self.nowState)
        print("startState",self.startState)
        if newState.upper() in self.endStates: # 如果跳到终止状态,则打印状态并结束循环
            print("reached ", newState)
            print("return to ",self.startState)
            self.nowState = self.startState
             
        else:                        # 否则将转移函数切换为新状态下的转移函数 
            self.handler = self.handlers[newState.upper()] 

                  


def origin_trans(txt):
    
    if(txt == "Psee"):
        newState = "search_score_state"
    elif(txt == "Nsee"):
        newState = "run_away_state"
    elif(txt == "unsee"):
        newState = "search_score_state"
    else:
        newState = "error_state"
    print("origin state->",newState)
    return newState

#search score state
def sss_trans(txt):
    
    if(txt == "Nsee"):
        newState = "run_away_state"
    elif(txt == "Psee"):
        newState = "search_score_state"
    elif(txt == "bigfish"):
        newState = "catch_state"
    elif(txt == "unsee"):
        newState = "search_score_state"
    else:
        newState = "error_state"
    print("search_score_state->",newState)
    return newState

def rw_trans(txt):
    if(txt == "unsee"):
        newState = "search_score_state"
    elif(txt == "Nsee"):
        newState = "run_away_state"
    elif(txt == "Psee"):
        newState = "catch_state"
    else:
        newState = "error_state"
    print("run_away_state->",newState)

    return newState

def c_trans(txt):
    if(txt == "unsee"):
        newState = "search_score_state"
    elif(txt == "Nsee"):
        newState = "run_away_state"
    elif(txt == "Psee"):
        newState = "catch_state"
    else:
        newState = "error_state"
    print("catch_state->",newState)

    return newState
        

    

if __name__== "__main__":
    m = StateMachine()
    '''
    m.add_state("Start", start_transitions)      # 添加初始状态
    m.add_state("Python_state", python_state_transitions)
    m.add_state("is_state", is_state_transitions)
    m.add_state("not_state", not_state_transitions)
    m.add_state("neg_state", None, end_state=1)  # 添加最终状态
    m.add_state("pos_state", None, end_state=1)
    '''
    m.add_state("start",origin_trans)
    m.add_state("search_score_state",sss_trans)
    m.add_state("run_away_state",rw_trans)
    m.add_state("catch_state",c_trans)
    m.set_start("start")
    m.add_state("error_state", None, end_state=1)
    
    m.set_start("Start") # 设置开始状态
    m.run("Psee")

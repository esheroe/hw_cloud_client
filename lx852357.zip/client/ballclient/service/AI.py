# -*- coding: utf-8 -*-
"""
Created on Wed Aug 21 20:00:57 2019

@author: tom
"""
from ballclient.service.astar import A_Star
from ballclient.service.GameMap import gameMap as gameMap
from ballclient.service.StateMachine import StateMachine
from ballclient.service.Log import logger
import math
import copy

class point:
    def __init__(self,x,y):
        self.x=x
        self.y=y
        
    #自定义了个打印函数
    def __str__(self):
        return "(%d, %d)"%(self.x,self.y)
    
    def distance(self,p):
        if math.fabs(self.x-p.x)>math.fabs(self.y-p.y):
            return math.fabs(self.x-p.x)
        else:
            return math.fabs(self.y-p.y)
    def equals(self,p):
        return self.x == p.x and self.y == p.y
        
class Transition:
    def __init__(self):
        '''
        t.P | t.SEE | t.BIGFISH = 19
        t.P | t.SEE             = 3
        t.SEE | t.BIGFISH       = 18
        t.SEE                   = 2
        UNSEE                   = 0
        '''
        self.N = 0
        self.P = 1
        self.SEE = 2
        self.BIGFISH = 16
        
class State:
    def __init__(self):
        self.START = "START_STATE"
        self.RUNAWAY = "RUNAWAY_STATE"
        self.SEARCH = "SEARCH_STATE"
        self.CATCH = "CATCH_STATE"
        self.ERROR = "ERROR_STATE"

class AI:
    
    '''这一块是类的共享变量，所有类的实例共享一份'''
    #四个分裂子图的中心坐标
    subMapCent = []
    
    #这个unsee map也是 y,x的方式储存坐标
    unseeMap   = []
    
    #stuipid数据

    '''共享变量END'''
    
    def __init__(self, id,vision,name):
        self.isvalid=True
        self.id=id
        self.vision=vision
        self.mpoint=point(0,0)
        self.vis_num=0
        self.waypoint=[]
        self.powers=[]
        self.target=point(0,0)
        self.name=name
        
        #保存看到过但还没吃的分值 
        self.seePowers = []
        
        #状态转移条件

        self.nowTState = 0 # P|SEE 
        #初始化状态机
        self.stateMachine = StateMachine()
        #转移条件 
        self.t = Transition()
        #状态转移加入到状态机中
        self.s = State()
        self.stateMachine.add_state(self.s.START,self.origin_transition)
        self.stateMachine.add_state(self.s.SEARCH,self.search_transition)
        self.stateMachine.add_state(self.s.RUNAWAY,self.runaway_transition)
        self.stateMachine.add_state(self.s.CATCH,self.catch_transition)
        self.stateMachine.add_state(self.s.ERROR, None, end_state=1)#终止状态
        self.stateMachine.set_start(self.s.START)#设置初始状态
        
        #状态动作函数，在某个状态执行某个函数
        self.stateAction = {}
        self.stateAction[self.s.START] = self.start
        self.stateAction[self.s.SEARCH] = self.search
        self.stateAction[self.s.RUNAWAY] = self.runaway
        self.stateAction[self.s.CATCH] = self.catch
        
        #self.test = 0#测试用的
        AI.subMapCent = [point(gameMap.subMap[0][0],gameMap.subMap[0][1]),\
              point(gameMap.subMap[1][0],gameMap.subMap[1][1]),\
              point(gameMap.subMap[2][0],gameMap.subMap[2][1]),\
              point(gameMap.subMap[3][0],gameMap.subMap[3][1])]
        
        AI.unseeMap = [[0 for col in range(gameMap.width)]\
                        for row in range(gameMap.height)]
        
        self.mCentre = point(0,0)
        #子图的两个边界点 
        self.subMap = []

        
    def update(self):
        self.isvalid=False
        for pinfo in gameMap.ourCurrentPlayer:
            if pinfo[0]==self.id:
                self.isvalid=True
                self.mpoint=point(pinfo[1],pinfo[2])
                
        #吃分检测
        for power in self.seePowers:
            if power not in gameMap.curpowers: #吃到分了
                self.seePowers.remove(power)
                
        #todo 我想把power all放在这个里面来，但是放进来后机器人就不动了，暂时没找到bug在哪    
        for cur_power in gameMap.curpowers:
            if(self.mpoint.distance(point(cur_power[1],cur_power[2])) <= self.vision):
                if cur_power not in self.seePowers:
                    self.seePowers.append(cur_power)
                    gameMap.curpowers.remove(cur_power) #从中取走这个点，避免和其他机器人冲突
                #print ("new ",self.name,": ",cur_power)
                logger.info("new %s: %s",self.name,cur_power)
                #print("gCurpowers:",gameMap.curpowers)
                break


        '''更新状态'''
        self.nowTState = 0 #每回合状态清零
        if gameMap.isOurPower():
            self.nowTState |= self.t.P #优势
        else:
            self.nowTState |= self.t.N #劣势
        
        for opp in gameMap.oppPlayer:
            if self.mpoint.distance(point(opp[1],opp[2])) <= self.vision:
                self.nowTState |= self.t.SEE     #看到敌人了
                if opp[3] >= 20:                     #大于20分的敌人认为是大鱼
                    self.nowTState |= self.t.BIGFISH #看到大鱼了
        
        '''更新unsee地图
        v = self.vision
        
        lx   = 0 if self.mpoint.x-v<0 else self.mpoint.x-v
        ly   = 0 if self.mpoint.y-v<0 else self.mpoint.y-v
        
        hx   = gameMap.width if self.mpoint.x+v >= gameMap.width else self.mpoint.x+v
        hy   = gameMap.width if self.mpoint.y+v >= gameMap.width else self.mpoint.y+v
        
        for x in range(lx,hx):
            for y in range(ly,hy):
                logger.finfo("range (%s,%y)",x,y)
                AI.unseeMap[y][x] = 1
        logger.finfo("=== unsee map ===")
        for i in range(len(AI.unseeMap)):
            logger.finfo(AI.unseeMap[i])
        
        '''
        
        
        #状态转移
    def origin_transition(self,TState):
        #在状态转移之前，执行一次start函数
        self.start()
        t = TState & 0x0f #取低四位
        if(t == self.t.P):
            newState = self.s.SEARCH
        elif(t == self.t.N):
            newState = self.s.SEARCH
        elif(t == self.t.SEE):
             newState = self.s.RUNAWAY
        elif(t == self.t.P | self.t.SEE):
            newState = self.s.SEARCH
        else:
            newState = "error_state"
        logger.finfo("origin state->",newState)
        return newState

    #search score state
    def search_transition(self,TState):
        
        t = TState & 0x0f #取低四位
        #这里要注意一下，没用低四位，而是加了可选择位，其他的elif用的低四位
        if(TState == self.t.P | self.t.BIGFISH | self.t.SEE):
            newState = self.s.CATCH
        elif(t == self.t.N):
            newState = self.s.SEARCH
        elif(t == self.t.SEE):
             newState = self.s.RUNAWAY
        elif(t == self.t.P | self.t.SEE):
            newState = self.s.SEARCH
        elif(t == self.t.P):
            newState = self.s.SEARCH
        else:
            newState = "error_state"
        logger.finfo("search_score_state->",newState)
        return newState
    
    def runaway_transition(self,TState):
        t = TState & 0x0f #取低四位
        if(TState == self.t.P | self.t.BIGFISH | self.t.SEE):
            newState = self.s.CATCH
        elif(t == self.t.N):
            newState = self.s.SEARCH
        elif(t == self.t.SEE):
             newState = self.s.RUNAWAY
        elif(t == self.t.P | self.t.SEE):
            newState = self.s.SEARCH
        elif(t == self.t.P):
            newState = self.s.SEARCH
        else:
            newState = "error_state"
        logger.finfo("run_away_state->",newState)
    
        return newState
    
    def catch_transition(self,TState):
        t = TState & 0x0f #取低四位
        if(TState == self.t.P | self.t.BIGFISH | self.t.SEE):
            newState = self.s.CATCH
        elif(t == self.t.N):
            newState = self.s.SEARCH
        elif(t == self.t.SEE):
             newState = self.s.RUNAWAY
        elif(t == self.t.P | self.t.SEE):
            newState = self.s.SEARCH
        elif(t == self.t.P):
            newState = self.s.SEARCH
        else:
            newState = "error_state"
        logger.finfo("catch_state->",newState)
    
        return newState
    
    #state action 在某个状态下做什么事，就在这里写了
    def search(self):
        logger.info("%s Do search", self.name)
        
    def catch(self):
        logger.info("%s Do catch", self.name)
        
    def runaway(self):
        logger.info("%s Do runaway", self.name)
        #simple runaway 
        
        
    #这个函数理论上只在leg start的时候执行，所以在这里分裂子图，初始化搜索
    def start(self):
        logger.info("%s Do start", self.name)
        
        #首先分裂图，成四个子图，选取每个子图的中心，根据距离选取每个人搜索的子图大小
        d = 25
        if self.mCentre.equals(point(0,0)):
            for c in AI.subMapCent:
                if c.distance(self.mpoint) < d:
                    d = c.distance(self.mpoint)
                    self.mCentre = c
            AI.subMapCent.remove(self.mCentre)
        logger.info("%s choose mCentre %s",self.name,self.mCentre)
        self.waypoint.append(self.mCentre)
        
        
        #选取中心点后建立未搜索子图
        halfx = int((gameMap.width+1)/2)
        halfy = int((gameMap.height+1)/2)
        x = gameMap.width
        y = gameMap.height
        

        #左上角        
        if self.mCentre.equals(point(gameMap.subMap[0][0],gameMap.subMap[0][1])):
            self.subMap = [0,0,halfx,halfy]
           
        #左下角
        elif self.mCentre.equals(point(gameMap.subMap[1][0],gameMap.subMap[1][1])):
            self.subMap = [0,halfy,halfx,y]
            
        #右上角
        elif self.mCentre.equals(point(gameMap.subMap[2][0],gameMap.subMap[2][1])):
            self.subMap = [halfx,0,x,halfy]
            
        #右下角
        elif self.mCentre.equals(point(gameMap.subMap[3][0],gameMap.subMap[3][1])):
            self.subMap = [halfx,halfy,x,y]
            
    # end def start()
        
            
        
        
    def run(self):
        if len(self.seePowers):
            self.target.x=self.seePowers[0][1]
            self.target.y=self.seePowers[0][2]
            #logger.info("%s target [%s,%s]",)
            #print(self.target.y,'choose  power',self.target.x,self.name)
            logger.info("%s choose power [%s,%s]",self.name,self.target.x,self.target.y)
            #必须保证waypoints不为空，否则肯定会出错
        else:
            if self.waypoint:#当waypoint不为空才赋值 
                logger.info("target为waypoint坐标")
                self.target.x=self.waypoint[self.vis_num].x
                self.target.y=self.waypoint[self.vis_num].y
            else:#否则就给自己坐标，不动
                logger.info("target为自身坐标")
                self.target.x = self.mpoint.x
                self.target.y = self.mpoint.y
        

        if self.mpoint.equals(self.target):
            #print('arrive waypoint ',self.vis_num,' ',self.mpoint.x,' ',self.mpoint.y)
            logger.info("%s arrive num[%s] waypoint: [%s,%s]",self.name,self.vis_num\
                        ,self.mpoint.x,self.mpoint.y)
            self.vis_num=self.vis_num+1
            if self.vis_num>=len(self.waypoint):
                self.vis_num=0
        
        
        
        
        #测试序列 理论上转移 origin state-> SEARCH_STATE -> CATCH -> RUNAWAY_STATE
        #test_queue = [(self.t.P | self.t.SEE),(self.t.P | self.t.SEE | self.t.BIGFISH),self.t.SEE]

        logger.finfo(self.name," nowTState: ",self.nowTState)
        self.stateMachine.run(self.nowTState)
        Do = self.stateAction[self.stateMachine.nowState]
        Do()
        
        
        
        
class Team:
    def __init__(self):
        self.stupid=AI(gameMap.ourPlayer[0],gameMap.vision,'stupid')
        self.idiot=AI(gameMap.ourPlayer[1],gameMap.vision,'idiot')
        self.fool=AI(gameMap.ourPlayer[2],gameMap.vision,'fool')
        self.git=AI(gameMap.ourPlayer[3],gameMap.vision,'git')
        
        '''
        self.stupid.waypoint.append(point(4,18))

        self.stupid.waypoint.append(point(4,4))
        
        self.idiot.waypoint.append(point(3,6))
        self.idiot.waypoint.append(point(11,6))
        self.idiot.waypoint.append(point(3,16))
       # self.idiot.waypoint.append(point(16,16))
        
        self.fool.waypoint.append(point(5,16))
        self.fool.waypoint.append(point(11,16))
        self.fool.waypoint.append(point(16,16))
        
        self.git.waypoint.append(point(16,18))
        self.git.waypoint.append(point(16,4))
        
        #self.git.waypoint.append(point(3,16))
        '''
        
        
        self.a_star = A_Star(0, 0, 0, 0,gameMap.height,gameMap.width)
    
    def update(self):
        self.stupid.update()
        self.idiot.update()
        self.fool.update()
        self.git.update()
        
    def process(self):
        self.update()
        #self.power_all()
        self.stupid.run()
        self.idiot.run()
        self.fool.run()
        self.git.run()
        action=[]
        if self.stupid.isvalid:
            action.append(self.a_star.find_path(self.stupid.mpoint.x,self.stupid.mpoint.y,self.stupid.target.x,self.stupid.target.y,self.stupid.name))
        else:
            action.append(0)
                
        if self.idiot.isvalid:
            action.append(self.a_star.find_path(self.idiot.mpoint.x,self.idiot.mpoint.y,self.idiot.target.x,self.idiot.target.y,self.idiot.name))
        else:
            action.append(0)
            
        if self.fool.isvalid:
            action.append(self.a_star.find_path(self.fool.mpoint.x,self.fool.mpoint.y,self.fool.target.x,self.fool.target.y,self.fool.name))
        else:
            action.append(0)
            
        if self.git.isvalid:
            action.append(self.a_star.find_path(self.git.mpoint.x,self.git.mpoint.y,self.git.target.x,self.git.target.y,self.git.name))
        else:
            action.append(0)
        return action
        
    def power_all(self):
        self.stupid.powers.clear()
        self.idiot.powers.clear()
        self.fool.powers.clear()
        self.git.powers.clear()
        for cur_power in gameMap.curpowers:
            if getdis(self.stupid.mpoint,point(cur_power[1],cur_power[2]))<=self.stupid.vision:
                self.stupid.powers.append(point(cur_power[1],cur_power[2]))
                #print ("stupid power: ",cur_power)
                continue
            if getdis(self.idiot.mpoint,point(cur_power[1],cur_power[2]))<=self.idiot.vision:
                self.idiot.powers.append(point(cur_power[1],cur_power[2]))
                #print ("idiot power: ",cur_power)
                continue
            if getdis(self.fool.mpoint,point(cur_power[1],cur_power[2]))<=self.fool.vision:
                self.fool.powers.append(point(cur_power[1],cur_power[2]))
                #print ("fool power: ",cur_power)
                continue
            if getdis(self.git.mpoint,point(cur_power[1],cur_power[2]))<=self.git.vision:
                self.git.powers.append(point(cur_power[1],cur_power[2]))
                #print ("git power: ",cur_power)
                continue
            
        
def getdis(p1,p2):
    if math.fabs(p1.x-p2.x)>math.fabs(p1.y-p2.y):
        return math.fabs(p1.x-p2.x)
    else:
        return math.fabs(p1.y-p2.y)
"""    
if 1:
    print('test') 
    player=[]
    power=[]
    for i in range(4):
        player.append(i) 
        power.append(point(i,i))
    moyu=Team(player,3)
    moyu.update()
    moyu.power_all(power)
    moyu.process()
    print('test')
"""
        
python3 -m ballclient.main $1 $2 $3
